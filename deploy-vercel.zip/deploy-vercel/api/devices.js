/* =====================================================================
   SIPINTAR — fungsi serverless Vercel untuk /api/devices
   Fase 37: kontrak API identik dengan server/server.js (sync LAN), tetapi
   state disimpan di KV eksternal (Upstash Redis / Vercel KV) karena
   serverless tidak punya disk. Seluruh logika ada di vercel-api-core.js.
   ===================================================================== */
'use strict';
const core = require('../vercel-api-core.js');

module.exports = function (req, res) {
  return core.api().handle(req, res, '/api/devices');
};
